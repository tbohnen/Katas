﻿using System;
using System.Collections.Generic;
using System.Resources;
using System.Text;

namespace GameOfLife
{
    class World
    {
        private readonly Grid _grid = new Grid();
        private readonly GenerationUpdater _generationUpdater;

        public World(IEnumerable<Cell> cells)
        {
            Seed(cells);
            _generationUpdater = new GenerationUpdater();
        }

        private void Seed(IEnumerable<Cell> cells)
        {
            foreach (var location in cells)
            {
                _grid.BringCellToLife(location);
            }
        }

        public void Tick()
        {
            _generationUpdater.MoveToNextGeneration(_grid);
        }

        public IEnumerable<Cell> LiveCells()
        {
            return _grid.LiveLocations();
        }
    }
}
