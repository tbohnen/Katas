﻿namespace GameOfLife
{
    internal enum State
    {
        Dead = 0,
        Alive = 1
    }
}